//
//  ai_anti_doomscrollTests.swift
//  ai_anti_doomscrollTests
//
//  Created by Enriko Chavez on 8/16/25.
//

import Testing
@testable import ai_anti_doomscroll

struct ai_anti_doomscrollTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
