import DeviceActivity
import Foundation
import os

class UsageMonitorExtension: DeviceActivityMonitor {
    private let logger = Logger(subsystem: "ai_anti_doomscroll", category: "UsageMonitor")
    
    override func intervalDidStart(for activity: DeviceActivityName) {
            logger.log("🟢 intervalDidStart triggered for \(activity.rawValue)")
        }

    override func intervalDidEnd(for activity: DeviceActivityName) {
        logger.log("🔴 intervalDidEnd triggered for \(activity.rawValue)")
    }
    
    override func eventDidReachThreshold(_ event: DeviceActivityEvent.Name, activity: DeviceActivityName) {
        logger.log("📱 Threshold reached for \(event.rawValue) in \(activity.rawValue)")
        // Called when user exceeds the configured threshold on the selected tokens
        sendToBackend(reason: event.rawValue)
    }

    private func sendToBackend(reason: String) {
        guard let defaults = UserDefaults(suiteName: Shared.appGroupId) else { return }

        // Read shared values saved by the app
        let baseURL = defaults.string(forKey: Shared.baseURLKey) ?? ""
        let phone   = defaults.string(forKey: Shared.phoneKey) ?? ""
        let minutes = defaults.integer(forKey: Shared.minutesKey)

        guard !baseURL.isEmpty, !phone.isEmpty,
              let url = URL(string: "\(baseURL)/trigger-call") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "phone": phone,
            "appName": "monitored_app",   // refine via reports if needed
            "minutes": minutes,
            "reason": reason
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        URLSession.shared.dataTask(with: req).resume()
    }
}
