// Shared.swift
import Foundation

// MARK: - App Group & shared keys
enum Shared {
    /// ⚠️ Change to your real App Group ID and enable App Groups in both targets
    static let appGroupId = "group.OrgIdentifier.ai-anti-doomscroll"

    /// Shared UserDefaults (App Group)
    static let defaults = UserDefaults(suiteName: appGroupId)!

    // Keys used by ContentView / NetworkManager
    static let selectionKey = "fc.selection"   // selection persistence (no-op wrapper below)
    static let minutesKey   = "fc.minutes"     // threshold minutes for monitoring
    static let phoneKey     = "userPhone"      // saved after OTP
    static let baseURLKey   = "baseURL"        // e.g. "http://your-mac.local:8000"
}

#if canImport(FamilyControls)
import FamilyControls

/// Lightweight, safe wrapper so ContentView can encode/decode a selection
/// without trying to serialize Apple’s token types (which don’t conform to Codable).
/// This is intentionally a no-op for persistence (we don’t need the selection
/// outside the app to start monitoring).
@available(iOS 16.0, *)
struct SelectionCodable: Codable {
    init(_ selection: FamilyActivitySelection) { }
    var value: FamilyActivitySelection { FamilyActivitySelection() }
}
#else
/// Shims so the app still compiles in Preview/Simulator where FamilyControls
/// isn’t available.
struct FamilyActivitySelection { init() {} }

struct SelectionCodable: Codable {
    init(_ selection: FamilyActivitySelection) { }
    var value: FamilyActivitySelection { FamilyActivitySelection() }
}
#endif
