//
//  ai_anti_doomscrollApp.swift
//  ai_anti_doomscroll
//
//  Created by Enriko Chavez on 8/16/25.
//

import SwiftUI

@main
struct ai_anti_doomscrollApp: App {
    @AppStorage("isLoggedIn") private var isLoggedIn = false

        init() {
            if let token = KeychainHelper.getToken(), !token.isEmpty {
                isLoggedIn = true
            } else {
                isLoggedIn = false
            }
        }

        var body: some Scene {
            WindowGroup {
                if isLoggedIn {
                    ContentView()
                } else {
                    LoginView()
                }
            }
        }
}
