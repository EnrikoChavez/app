import SwiftUI

#if canImport(FamilyControls)
import FamilyControls
#endif

#if canImport(DeviceActivity)
import DeviceActivity
#endif

// MARK: - Models
struct Todo: Identifiable, Codable {
    let id: Int?
    var task: String
}

// MARK: - Selection persistence (App ↔ Extension via App Group)
final class SelectionStore: ObservableObject {
    #if canImport(FamilyControls)
    @Published var selection = FamilyActivitySelection() {
        didSet { persist() }
    }
    #else
    @Published var selection = FamilyActivitySelection() // dummy placeholder
    #endif

    init() {
        #if canImport(FamilyControls)
        if let data = Shared.defaults.data(forKey: Shared.selectionKey),
           let decoded = try? JSONDecoder().decode(SelectionCodable.self, from: data) {
            selection = decoded.value
        }
        #endif
    }

    private func persist() {
        #if canImport(FamilyControls)
        if let data = try? JSONEncoder().encode(SelectionCodable(selection)) {
            Shared.defaults.set(data, forKey: Shared.selectionKey)
        }
        #endif
    }
}

// MARK: - Networking helper (reads baseURL + phone from storage)
final class NetworkManager {
    private var baseURL: String {
        Shared.defaults.string(forKey: Shared.baseURLKey)
        ?? "http://MacBook-Pro-80.local:8000"
    }

    private var savedPhone: String {
        UserDefaults.standard.string(forKey: "userPhone") ?? ""
    }

    func triggerTestCall(completion: @escaping (String) -> Void) {
        guard let url = URL(string: "\(baseURL)/trigger-call") else {
            completion("❌ Invalid URL")
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "phone": savedPhone,
            "appName": "Instagram",
            "minutes": 15
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        URLSession.shared.dataTask(with: req) { _, resp, err in
            if let err = err { completion("❌ \(err.localizedDescription)"); return }
            if let http = resp as? HTTPURLResponse {
                completion("✅ Server: \(http.statusCode)")
            } else {
                completion("⚠️ No response")
            }
        }.resume()
    }

    func fetchTodos(completion: @escaping ([Todo]) -> Void) {
        guard let url = URL(string: "\(baseURL)/todos") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let decoded = try? JSONDecoder().decode([String:[Todo]].self, from: data),
                  let todos = decoded["todos"] else {
                completion([])
                return
            }
            completion(todos)
        }.resume()
    }

    func addTodo(_ task: String, completion: @escaping () -> Void) {
        guard let url = URL(string: "\(baseURL)/todos") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = Todo(id: nil, task: task)
        req.httpBody = try? JSONEncoder().encode(body)
        URLSession.shared.dataTask(with: req) { _, _, _ in completion() }.resume()
    }

    func deleteTodo(id: Int, completion: @escaping () -> Void) {
        guard let url = URL(string: "\(baseURL)/todos/\(id)") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"
        URLSession.shared.dataTask(with: req) { _, _, _ in completion() }.resume()
    }
}

// MARK: - ContentView (merged UI)
struct ContentView: View {
    @State private var serverResponse: String = "Idle"
    @State private var todos: [Todo] = []
    @State private var newTask = ""
    @AppStorage("isLoggedIn") private var isLoggedIn = false
    @State private var phone = UserDefaults.standard.string(forKey: "userPhone") ?? ""

    @StateObject private var store = SelectionStore()
    @State private var showPicker = false
    @State private var minutesText = "15"
    @State private var authStatus = "Unknown"
    @State private var starting = false

    #if canImport(DeviceActivity)
    private let center = DeviceActivityCenter()
    #endif

    let networkManager = NetworkManager()

    private var baseURL: String {
        Shared.defaults.string(forKey: Shared.baseURLKey)
        ?? "http://MacBook-Pro-80.local:8000"
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    Text("🛑 Anti-Doomscroll")
                        .font(.largeTitle).bold()

                    Text("Status: \(serverResponse)")
                        .font(.subheadline)
                        .foregroundColor(.gray)

                    Button {
                        networkManager.triggerTestCall { result in
                            DispatchQueue.main.async { self.serverResponse = result }
                        }
                    } label: {
                        Text("📞 Test Call Now")
                            .bold()
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue.opacity(0.8))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }

                    Divider()

                    // To-dos
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Your To-Do List").font(.headline)
                            Spacer()
                            Text(phone).font(.footnote).foregroundColor(.secondary)
                        }

                        HStack {
                            TextField("New task", text: $newTask)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Button("Add") { addTodo() }
                                .buttonStyle(.borderedProminent)
                        }

                        List {
                            ForEach(todos) { todo in
                                HStack {
                                    Text(todo.task)
                                    Spacer()
                                    Button {
                                        if let id = todo.id { deleteTodo(id: id) }
                                    } label: {
                                        Image(systemName: "trash").foregroundColor(.red)
                                    }
                                }
                            }
                        }
                        .frame(minHeight: 200)
                    }

                    Button("Logout") { logout() }
                        .buttonStyle(.borderedProminent)
                        .tint(.red)

                    Divider()

                    // FamilyControls UI only on device
                    #if canImport(FamilyControls)
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Screen Time Monitoring").font(.headline)
                        Text("Authorization: \(authStatus)").foregroundColor(.secondary)

                        HStack(spacing: 12) {
                            Button("Request Authorization") {
                                Task { await requestAuth() }
                            }
                            .buttonStyle(.bordered)

                            Button("Select Apps / Categories") { showPicker = true }
                                .buttonStyle(.borderedProminent)
                        }
                        .familyActivityPicker(isPresented: $showPicker, selection: $store.selection)

                        HStack {
                            Text("Minutes:")
                            TextField("15", text: $minutesText)
                                .keyboardType(.numberPad)
                                .textFieldStyle(.roundedBorder)
                                .frame(width: 80)
                        }

                        Button {
                            Task { await startMonitoring() }
                        } label: {
                            HStack { if starting { ProgressView() }; Text("Start Monitoring") }
                        }
                        .disabled(starting || isSelectionEmpty)
                        .buttonStyle(.borderedProminent)

                        Text("Use a selected app for the configured minutes to trigger a backend call.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    #else
                    Text("👀 FamilyControls not available in Preview/Simulator")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                    #endif
                }
                .padding()
            }
        }
        .onAppear {
            if Shared.defaults.string(forKey: Shared.baseURLKey) == nil {
                Shared.defaults.set(baseURL, forKey: Shared.baseURLKey)
            }
            Shared.defaults.set(phone, forKey: Shared.phoneKey)

            #if canImport(FamilyControls)
            Task { await updateAuthStatus() }
            #endif

            fetchTodos()
        }
    }

    // MARK: - Helpers

    private var isSelectionEmpty: Bool {
        #if canImport(FamilyControls)
        store.selection.applicationTokens.isEmpty
        && store.selection.categoryTokens.isEmpty
        && store.selection.webDomainTokens.isEmpty
        #else
        true
        #endif
    }

    #if canImport(FamilyControls)
    private func requestAuth() async {
        do {
            try await AuthorizationCenter.shared.requestAuthorization(for: .individual)
            await updateAuthStatus()
        } catch {
            await MainActor.run { authStatus = "Error: \(error.localizedDescription)" }
        }
    }

    private func updateAuthStatus() async {
        let status = AuthorizationCenter.shared.authorizationStatus
        await MainActor.run { authStatus = "\(status)" }
    }

    private func startMonitoring() async {
        starting = true
        defer { starting = false }

        let minutes = Int(minutesText) ?? 15
        Shared.defaults.set(minutes, forKey: Shared.minutesKey)

        let eventName = DeviceActivityEvent.Name("usageThreshold")
        let event = DeviceActivityEvent(
            applications: store.selection.applicationTokens,
            categories:  store.selection.categoryTokens,
            webDomains:  store.selection.webDomainTokens,
            threshold: DateComponents(minute: minutes)
        )

        let now = Date()
        let calendar = Calendar.current
        let components: Set<Calendar.Component> = [.hour, .minute, .second]
        let startDate = calendar.date(bySettingHour: 0, minute: 0, second: 0, of: now)!
        let endDate = calendar.date(bySettingHour: 23, minute: 59, second: 0, of: now)!
        let intervalStart = calendar.dateComponents(components, from: startDate)
        let intervalEnd = calendar.dateComponents(components, from: endDate)

        let schedule = DeviceActivitySchedule(
            intervalStart: intervalStart,
            intervalEnd: intervalEnd,
            repeats: true
        )

        do {
            try center.startMonitoring(
                DeviceActivityName("dailyMonitor"),
                during: schedule,
                events: [eventName: event]
            )
            print("✅ Monitoring started")
            print("Event Name: \(eventName.rawValue)")

            // Debug: event tokens & threshold
            #if canImport(FamilyControls)
            print("Applications: \(event.applications)")
            print("Categories: \(event.categories)")
            print("WebDomains: \(event.webDomains)")
            #endif
            if let mins = event.threshold.minute {
                print("Threshold: \(mins) minutes")
            }

            // Debug: schedule info
            print("Schedule interval start: \(schedule.intervalStart)")
            print("Schedule interval end: \(schedule.intervalEnd)")
            print("Repeats: \(schedule.repeats)")
        } catch {
            print("startMonitoring error:", error)
        }
    }
    #endif

    private func fetchTodos() {
        networkManager.fetchTodos { items in
            DispatchQueue.main.async { self.todos = items }
        }
    }

    private func addTodo() {
        guard !newTask.isEmpty else { return }
        networkManager.addTodo(newTask) { fetchTodos() }
        newTask = ""
    }

    private func deleteTodo(id: Int) {
        networkManager.deleteTodo(id: id) { fetchTodos() }
    }

    private func logout() {
        KeychainHelper.deleteToken()
        UserDefaults.standard.removeObject(forKey: "userPhone")
        Shared.defaults.removeObject(forKey: Shared.phoneKey)
        isLoggedIn = false
    }
}

#Preview {
    ContentView()
}
